package com.jzt.api.domain;

import java.util.Date;

public class Businessman {
    private Integer id;

    private Integer cid;

    private String name;

    private String imgDir;

    private String img;

    private String post;

    private Integer sex;

    private Integer age;

    private Integer education;

    private Integer schoolType;

    private String school;

    private Integer schoolType2;

    private String school2;

    private Integer hasProfessionalCertificate;

    private String professionalCertificate;

    private Integer workExperience;

    private Integer enterpriseType;

    private Integer enterpriseField;

    private Integer hasManagementWork;

    private String other;

    private Date createTime;

    private Date updateTime;

    private Integer isDelete;

    private String des;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImgDir() {
        return imgDir;
    }

    public void setImgDir(String imgDir) {
        this.imgDir = imgDir;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getEducation() {
        return education;
    }

    public void setEducation(Integer education) {
        this.education = education;
    }

    public Integer getSchoolType() {
        return schoolType;
    }

    public void setSchoolType(Integer schoolType) {
        this.schoolType = schoolType;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public Integer getSchoolType2() {
        return schoolType2;
    }

    public void setSchoolType2(Integer schoolType2) {
        this.schoolType2 = schoolType2;
    }

    public String getSchool2() {
        return school2;
    }

    public void setSchool2(String school2) {
        this.school2 = school2;
    }

    public Integer getHasProfessionalCertificate() {
        return hasProfessionalCertificate;
    }

    public void setHasProfessionalCertificate(Integer hasProfessionalCertificate) {
        this.hasProfessionalCertificate = hasProfessionalCertificate;
    }

    public String getProfessionalCertificate() {
        return professionalCertificate;
    }

    public void setProfessionalCertificate(String professionalCertificate) {
        this.professionalCertificate = professionalCertificate;
    }

    public Integer getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(Integer workExperience) {
        this.workExperience = workExperience;
    }

    public Integer getEnterpriseType() {
        return enterpriseType;
    }

    public void setEnterpriseType(Integer enterpriseType) {
        this.enterpriseType = enterpriseType;
    }

    public Integer getEnterpriseField() {
        return enterpriseField;
    }

    public void setEnterpriseField(Integer enterpriseField) {
        this.enterpriseField = enterpriseField;
    }

    public Integer getHasManagementWork() {
        return hasManagementWork;
    }

    public void setHasManagementWork(Integer hasManagementWork) {
        this.hasManagementWork = hasManagementWork;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}