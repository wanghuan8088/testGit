package com.jzt.api.controller;

import com.jzt.api.controller.base.BaseController;

/**
 *  金融新榜
 */
public class RankController extends BaseController{
}
